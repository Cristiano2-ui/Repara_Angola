<?php

use App\classes\Routes;


const PATH_VIEWS = '/app/views/';
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$absolute_path = explode('/', __DIR__);
$project_name = "/" . $absolute_path[sizeof($absolute_path) - 1] . "/";

$routes = [

    $project_name . '' => 'inicio.php',
    $project_name . 'login' => 'login.php',
    $project_name . 'admin' => 'admin/dashboard.php',
    $project_name . 'perfil' => 'perfil.php'


];


function view(String $file_name)
{

    if (file_exists(__DIR__ . PATH_VIEWS . $file_name)) {

        include_once __DIR__ . PATH_VIEWS . $file_name;
    } else {

        die('a view não foi encontrada');
    }
}

if (array_key_exists($uri, $routes)) {

    view($routes[$uri]);
}