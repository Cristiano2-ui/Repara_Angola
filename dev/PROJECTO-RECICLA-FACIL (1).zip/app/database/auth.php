<?php
session_start();

// Conexão
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'sr';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$action = $_POST['action'] ?? '';

if ($action === 'register') {

    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar = $_POST['confirmar_senha'] ?? '';
    $localizacao = $_POST['localizacao'] ?? '';
    $tipo_usuario = 'cidadao'; // padrão

    // === VALIDAÇÕES ===

   
    if (empty($nome) || strlen($nome) < 3) {
        die("O nome deve ter pelo menos 3 caracteres.");
    }

   
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Informe um e-mail válido.");
    }


    $verifica_email = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $verifica_email->bind_param("s", $email);
    $verifica_email->execute();
    $verifica_email->store_result();

    if ($verifica_email->num_rows > 0) {
        die("Este e-mail já está cadastrado.");
    }

    $verifica_email->close();

  
    if (empty($senha) || strlen($senha) < 6) {
        die("A senha deve ter pelo menos 6 caracteres.");
    }

   
    if ($senha !== $confirmar) {
        die("As senhas não coincidem.");
    }

   
    if (empty($localizacao)) {
        die("Por favor, selecione uma localização.");
    }

  
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

  
    $stmt = $conn->prepare("INSERT INTO users (nome, email, senha, tipo_usuario, localizacao, created_at) VALUES (?, ?, ?, ?, ?, NOW())");



    
    $stmt->bind_param("sssss", $nome, $email, $senha_hash, $tipo_usuario, $localizacao);

    if ($stmt->execute()) {
        echo "<script>alert('Cadastro feito com sucesso!'); window.location.href = 'index.php';</script>";
    } else {
        echo "Erro ao cadastrar: " . $stmt->error;
    }

    $stmt->close();

} elseif ($action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

   
    if (empty($email) || empty($senha)) {
        die("Preencha todos os campos.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("E-mail inválido.");
    }

    // Buscar usuário
    $stmt = $conn->prepare("SELECT id, nome, senha, tipo_usuario FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['user_id'] = $usuario['id'];
            $_SESSION['user_nome'] = $usuario['nome'];
            $_SESSION['user_tipo'] = $usuario['tipo_usuario'];

           
            if ($usuario['tipo_usuario'] === 'empresa') {
                header("Location: views/empresa/dashboard.php");
            } else {
                header("Location: views/layouts/home.php");
            }

            exit;
        } else {
            die("Senha incorreta.");
        }
    } else {
        die("Usuário não encontrado.");
    }

    $stmt->close();
} else {
    echo "Ação não reconhecida.";
}

$conn->close();
?>
