<!-- <?php
// $host = 'localhost';
// $user = 'root';
// $pass = '';
// $dbname = 'sr';

// $conn = new mysqli($host, $user, $pass, $dbname);
// if ($conn->connect_error) {
//     die("Erro na conexão: " . $conn->connect_error);
// }

// $nome = 'Repara Angola Admin';
// $email = 'reparaangola@gmail.com';
// $senha = '12345678'; // senha padrão
// $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
// $localizacao = 'Luanda';
// $tipo_usuario = 'empresa';

// $stmt = $conn->prepare("INSERT INTO users (nome, email, senha, tipo_usuario, localizacao, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
// $stmt->bind_param("sssss", $nome, $email, $senha_hash, $tipo_usuario, $localizacao);

// if ($stmt->execute()) {
//     echo "Usuário empresa criado com sucesso!";
// } else {
//     echo "Erro ao criar: " . $stmt->error;
// }

// $stmt->close();
// $conn->close();
?> -->
