<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="public/css/style.css">
    <!-- <link rel="stylesheet" href="public/css/login.css"> -->

    <link rel="stylesheet" href="public/fonts/remixicon.css">
</head>

<body class="w-full min-h-screen bg-gray-200">

    <?php
    require_once("boostrap.php");

    ?>

</body>

</html>