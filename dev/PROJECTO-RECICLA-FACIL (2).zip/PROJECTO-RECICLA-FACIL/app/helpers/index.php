<?php

namespace App\helpers;





function dd($variable)
{
    var_dump($variable);
    die('');
}
