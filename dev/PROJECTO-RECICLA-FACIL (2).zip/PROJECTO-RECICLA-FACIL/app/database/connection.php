<?php

$connection = null;

try {
    $connection = mysqli_connect("localhost", "root", "", "SR");

} catch (\Throwable $th) {

     echo "404";
}

if (!$connection) {

    die("Connection failed: " . mysqli_connect_error());
    
}