<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cadastro de Material</title>
  <link href="https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css" rel="stylesheet" />
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background: #f1f5f9;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .form-wrapper {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 60px 20px;
      width: 100%;
    }

    .form-content {
      background-color: #ffffff;
      border-radius: 16px;
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
      padding: 40px;
      max-width: 800px;
      width: 100%;
    }

    .form-title {
      text-align: center;
      margin-bottom: 30px;
    }

    .form-title h2 {
      margin: 0;
      font-size: 28px;
      color: #1e293b;
    }

    .form-fields {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      margin-bottom: 30px;
    }

    .input-group {
      position: relative;
      display: flex;
      flex-direction: column;
    }

    .input-group.full {
      grid-column: 1 / -1;
    }

    .input-group label {
      font-weight: 600;
      margin-bottom: 6px;
      color: #334155;
    }

    .input-group i {
      position: absolute;
      top: 38px;
      left: 12px;
      font-size: 18px;
      color: #94a3b8;
    }

    .input-group input,
    .input-group select,
    .input-group textarea {
      padding: 12px 12px 12px 38px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background-color: #f8fafc;
      font-size: 15px;
      transition: border-color 0.2s ease;
    }

    .input-group input:focus,
    .input-group select:focus,
    .input-group textarea:focus {
      outline: none;
      border-color: #08673f;
      background-color: #ffffff;
    }

    .input-group textarea {
      min-height: 100px;
      resize: vertical;
    }

    .input-group input[type="file"] {
      padding-left: 38px;
    }

    .submit-btn {
      display: block;
      margin: 0 auto;
      padding: 14px 36px;
      font-size: 16px;
      font-weight: bold;
      background-color: #2b6354;
      color: #ffffff;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .submit-btn:hover {
      background-color: #245c4c;
    }

    @media (max-width: 680px) {
      .form-fields {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <header class="h-16 bg-slate-800 text-white flex items-center justify-center w-full">
    <div class="container flex items-center justify-between px-2 w-full max-w-6xl">
      <span><img src="public/Recicla.png" alt="" class="size-12"></span>
      <nav class="flex items-center gap-10">
        <a href="home">Início</a>
        <a href="sobre">Sobre</a>
        <form action="logout.php" method="POST">
          <button type="submit" class="bg-red-600 hover:bg-red-700 px-4 py-1 rounded-md text-white text-sm">
            <i class="ri-logout-box-r-line mr-1"></i> Sair
          </button>
        </form>
      </nav>
    </div>
  </header>

  <div class="form-wrapper">
    <form class="form-content" method="POST" enctype="multipart/form-data">
      <div class="form-title">
        <h2>Cadastro de Material</h2>
      </div>

      <div class="form-fields">
        <div class="input-group tipo-material-group">
          <label for="tipo">Tipo de Material</label>
          <i class="ri-box-3-line"></i>
          <select id="tipo" name="tipo_material" required>
            <option value="">Selecione o tipo de material</option>
            <option value="papel">Papel (kg) - 100 KZ/kg</option>
            <option value="papelao">Papelão (kg) - 150 KZ/kg</option>
            <option value="plastico_kg">Plástico (kg) - 200 KZ/kg</option>
            <option value="plastico_un">Plástico (un) - 20 KZ/un</option>
            <option value="vidro">Vidro (kg) - 50 KZ/kg</option>
            <option value="aluminio">Alumínio (kg) - 1200 KZ/kg</option>
            <option value="ferro">Ferro (kg) - 400 KZ/kg</option>
            <option value="cobre">Cobre (kg) - 2000 KZ/kg</option>
            <option value="lata_kg">Latas (kg) - 300 KZ/kg</option>
            <option value="lata_un">Latas (un) - 15 KZ/un</option>
            <option value="eletronico_kg">Eletrônicos (kg) - 500 KZ/kg</option>
            <option value="eletronico_un">Eletrônicos (un) - 1000 KZ/un</option>
            <option value="bateria_pilha">Baterias e Pilhas (un) - 100 KZ/un</option>
            <option value="oleo">Óleo de cozinha usado (L) - 250 KZ/L</option>
            <option value="tecido">Tecidos (kg) - 200 KZ/kg</option>
          </select>
        </div>

        <div class="input-group estado-group">
          <label for="estado">Estado</label>
          <i class="ri-shield-check-line"></i>
          <select id="estado" name="estado" required>
            <option value="">Selecione...</option>
            <option value="novo">Novo</option>
            <option value="bom">Bom</option>
            <option value="usado">Usado</option>
            <option value="danificado">Danificado</option>
          </select>
        </div>

        <div class="input-group full descricao-group">
          <label for="descricao">Descrição</label>
          <i class="ri-file-text-line"></i>
          <textarea id="descricao" name="descricao" placeholder="Descreva os detalhes do material..."></textarea>
        </div>

        <div class="input-group foto-group">
          <label for="foto">Foto</label>
          <i class="ri-image-line"></i>
          <input type="file" id="foto" name="foto" accept="image/*">
        </div>

        <div class="input-group localizacao-group">
          <label for="localizacao">Localização</label>
          <i class="ri-map-pin-line"></i>
          <input type="text" id="localizacao" name="localizacao" placeholder="Ex: Armazém A - Prateleira 2">
        </div>

        <div class="input-group quantidade-group">
          <label for="quantidade">Quantidade</label>
          <i class="ri-numbers-line"></i>
          <input type="number" id="quantidade" name="quantidade" min="1" placeholder="Ex: 15" required>
        </div>

        <div class="input-group unidade-group">
          <label for="unidade">Unidade</label>
          <i class="ri-numbers-line"></i>
          <select id="unidade" name="unidade">
            <option value="kilogramas">Kg</option>
            <option value="gramas">G</option>
            <option value="toneladas">T</option>
          </select>
        </div>

        <div class="input-group preco-group">
          <label for="preco_unitario">Preço Unitário (KZ)</label>
          <i class="ri-money-dollar-circle-line"></i>
          <input type="text" id="preco_unitario" readonly placeholder="0 KZ">
        </div>

        <div class="input-group total-group">
          <label for="valor_total">Valor Total (KZ)</label>
          <i class="ri-calculator-line"></i>
          <input type="text" id="valor_total" readonly placeholder="0 KZ">
        </div>
      </div>

      <button type="submit" class="submit-btn">Enviar Material</button>
    </form>
  </div>

  <footer class="bg-gray-800 text-white w-full z-50">
    <div class="container mx-auto px-6 py-12 flex flex-col md:flex-row justify-between items-center gap-8">
      <div class="flex flex-col justify-center items-center text-center md:text-left">
        <span><img src="public/Recicla.png" alt="" class="size-12"></span>
        <h2 class="text-2xl font-bold">Repara Angola</h2>
        <p class="text-sm mt-2 text-gray-300">ganhe salvando o mundo</p>
      </div>
      <div class="flex flex-col gap-2 text-sm text-gray-400">
        <a href="#" class="hover:text-white transition">Início</a>
        <a href="#" class="hover:text-white transition">Sobre</a>
        <a href="#" class="hover:text-white transition">Contato</a>
        <a href="#" class="hover:text-white transition">FAQ</a>
      </div>
      <div class="flex items-center gap-4">
        <a href="#" class="hover:text-teal-400 text-xl"><i class="ri-facebook-circle-fill"></i></a>
        <a href="#" class="hover:text-teal-400 text-xl"><i class="ri-instagram-line"></i></a>
        <a href="#" class="hover:text-teal-400 text-xl"><i class="ri-whatsapp-line"></i></a>
      </div>
    </div>

    <div class="text-center text-xs text-gray-500 border-t border-gray-700 py-4">
      © <?= date('Y') ?> Repara Angola. Todos os direitos reservados.
    </div>
  </footer>

  <script>
    const precos = {
      papel: 100,
      papelao: 150,
      plastico_kg: 200,
      plastico_un: 20,
      vidro: 50,
      aluminio: 1200,
      ferro: 400,
      cobre: 2000,
      lata_kg: 300,
      lata_un: 15,
      eletronico_kg: 500,
      eletronico_un: 1000,
      bateria_pilha: 100,
      oleo: 250,
      tecido: 200
    };

    const tipoSelect = document.getElementById("tipo");
    const quantidadeInput = document.getElementById("quantidade");
    const precoInput = document.getElementById("preco_unitario");
    const totalInput = document.getElementById("valor_total");

    function atualizarPreco() {
      const tipo = tipoSelect.value;
      const quantidade = parseFloat(quantidadeInput.value) || 0;
      const precoUnitario = precos[tipo] || 0;
      const total = precoUnitario * quantidade;

      precoInput.value = precoUnitario + " KZ";
      totalInput.value = total + " KZ";
    }

    tipoSelect.addEventListener("change", atualizarPreco);
    quantidadeInput.addEventListener("input", atualizarPreco);
  </script>

</body>
</html>
