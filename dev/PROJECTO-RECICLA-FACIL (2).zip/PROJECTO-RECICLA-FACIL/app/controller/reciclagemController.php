<?php
session_start();

// Corrigir os caminhos com __DIR__
require_once __DIR__ . '/../../boostrap.php';
require_once __DIR__ . '/connection.php';


// Verifica se os dados vieram por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo_material = $_POST['tipo_material'];
    $estado = $_POST['estado'];
    $descricao = $_POST['descricao'];
    $localizacao = $_POST['localizacao'];
    $quantidade = $_POST['quantidade'];
    $unidade = $_POST['unidade'];
    $preco_total = calcularPreco($tipo_material, $quantidade);

    // Upload da imagem
    $foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $nome_arquivo = time() . '_' . $_FILES['foto']['name'];
        $destino = 'uploads/' . $nome_arquivo;
        move_uploaded_file($_FILES['foto']['tmp_name'], $destino);
        $foto = $destino;
    }

    $connection = conectarBanco();
    $stmt = $connection->prepare("INSERT INTO residuos (tipo_material, estado_conservacao, descricao, foto, localizacao, quantidade_estimada_kg, unidade, preco_total, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssssdss", $tipo_material, $estado, $descricao, $foto, $localizacao, $quantidade, $unidade, $preco_total);
    
    if ($stmt->execute()) {
        echo "Material cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar: " . $stmt->error;
    }

    $stmt->close();
    $connection->close();
}

function calcularPreco($tipo, $qtd) {
    $precos = [
        'papel' => 100,
        'papelao' => 150,
        'plastico_kg' => 200,
        'plastico_un' => 20,
        'vidro' => 50,
        'aluminio' => 1200,
        'ferro' => 400,
        'cobre' => 2000,
        'lata_kg' => 300,
        'lata_un' => 15,
        'eletronico_kg' => 500,
        'eletronico_un' => 1000,
        'bateria_pilha' => 100,
        'oleo' => 250,
        'tecido' => 200,
    ];

    return isset($precos[$tipo]) ? $precos[$tipo] * $qtd : 0;
}
